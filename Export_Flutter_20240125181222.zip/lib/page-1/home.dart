import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1193;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homeUPd (1:2)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff000000)),
          color: Color(0xbf070707),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/background-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // topsKH (1:3)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 191.5*fem),
              width: 1225*fem,
              height: 174*fem,
              decoration: BoxDecoration (
                color: Color(0xcc383838),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // bannerAJP (1:218)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(80*fem, 28*fem, 108*fem, 27*fem),
                      width: 424*fem,
                      height: 174*fem,
                      decoration: BoxDecoration (
                        color: Color(0x991a1a1a),
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Container(
                        // logoeUT (1:219)
                        padding: EdgeInsets.fromLTRB(16*fem, 8*fem, 16*fem, 9*fem),
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0x4c1a1a1a),
                          borderRadius: BorderRadius.circular(5*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(5*fem, 5*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // image1kA7 (1:222)
                              width: 204*fem,
                              height: 54*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(5*fem),
                                child: Image.asset(
                                  'assets/page-1/images/image-1-J2o.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 3*fem,
                            ),
                            Center(
                              // staatlicherealschulehauzenberg (1:220)
                              child: Container(
                                width: double.infinity,
                                child: Text(
                                  'Staatliche Realschule Hauzenberg',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    decoration: TextDecoration.underline,
                                    color: Color(0xffffffff),
                                    decorationColor: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 3*fem,
                            ),
                            Container(
                              // autogroupn4kbH3Z (71pD4xVT92Tgqpzda8n4kB)
                              margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 137*fem, 0*fem),
                              width: double.infinity,
                              height: 12*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // phoneiconBud (1:223)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x4c1a1a1a),
                                      borderRadius: BorderRadius.circular(5*fem),
                                    ),
                                    child: Center(
                                      // phoneauricularsymbol1U83 (1:224)
                                      child: SizedBox(
                                        width: 8*fem,
                                        height: 8*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/phone-auricular-symbol-1-WDH.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // ags (1:221)
                                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                    child: Text(
                                      '08586 1550',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 3*fem,
                            ),
                            Container(
                              // autogroupppxzG3u (71pDC7xBYVNPsLHgxvpPXZ)
                              margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 137*fem, 0*fem),
                              width: double.infinity,
                              height: 12*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // phoneiconzEo (1:226)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x4c1a1a1a),
                                      borderRadius: BorderRadius.circular(5*fem),
                                    ),
                                    child: Center(
                                      // phoneauricularsymbol1VxF (1:227)
                                      child: SizedBox(
                                        width: 8*fem,
                                        height: 8*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/phone-auricular-symbol-1.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // 2BV (1:225)
                                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                    child: Text(
                                      '08586 1550',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 8*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // selectionwZM (1:4)
                    left: 355*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(61*fem, 23*fem, 62*fem, 22*fem),
                      width: 838*fem,
                      height: 174*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff343434),
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupcykfpd9 (71pDXrtHoFBBVBKWktCykf)
                            width: 337*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // logokmh (3:323)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                  padding: EdgeInsets.fromLTRB(10*fem, 8*fem, 10*fem, 8*fem),
                                  width: double.infinity,
                                  height: 59*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff000000)),
                                    color: Color(0x4c1a1a1a),
                                    borderRadius: BorderRadius.circular(5*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(5*fem, 5*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                  child: Container(
                                    // logoqHM (3:325)
                                    padding: EdgeInsets.fromLTRB(49*fem, 9*fem, 49*fem, 9*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x4c1a1a1a),
                                      borderRadius: BorderRadius.circular(5*fem),
                                    ),
                                    child: Text(
                                      'Suche...',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupritmiM9 (71pDdriJEHULCuP1E4RiTM)
                                  width: double.infinity,
                                  height: 59*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // logoekb (3:20)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                                        width: 148*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0xff000000)),
                                          color: Color(0x4c1a1a1a),
                                          borderRadius: BorderRadius.circular(5*fem),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(5*fem, 5*fem),
                                              blurRadius: 2*fem,
                                            ),
                                          ],
                                        ),
                                        child: Center(
                                          child: Center(
                                            child: Text(
                                              'Schulprofil',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 20*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // logo5qu (3:24)
                                        width: 148*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0xff000000)),
                                          color: Color(0x4c1a1a1a),
                                          borderRadius: BorderRadius.circular(5*fem),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(5*fem, 5*fem),
                                              blurRadius: 2*fem,
                                            ),
                                          ],
                                        ),
                                        child: Center(
                                          child: Center(
                                            child: Text(
                                              'Schulebene',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 20*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 41*fem,
                          ),
                          Container(
                            // autogrouppzfmjfZ (71pDqBikph9Au3wNn4Pzfm)
                            width: 148*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // logogao (3:28)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                  width: double.infinity,
                                  height: 59*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff000000)),
                                    color: Color(0x4c1a1a1a),
                                    borderRadius: BorderRadius.circular(5*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(5*fem, 5*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        'Blog',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // logovEF (3:30)
                                  width: double.infinity,
                                  height: 59*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff000000)),
                                    color: Color(0x4c1a1a1a),
                                    borderRadius: BorderRadius.circular(5*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(5*fem, 5*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        'Kontakt',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 41*fem,
                          ),
                          Container(
                            // autogroupekcfmEs (71pDxmLTeT8HtcxZnaEKCF)
                            width: 148*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // logoWCT (3:18)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                  width: double.infinity,
                                  height: 59*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff000000)),
                                    color: Color(0x4c1a1a1a),
                                    borderRadius: BorderRadius.circular(5*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(5*fem, 5*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        'Schule',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // logo8Dq (3:22)
                                  width: double.infinity,
                                  height: 59*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff000000)),
                                    color: Color(0x4c1a1a1a),
                                    borderRadius: BorderRadius.circular(5*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(5*fem, 5*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        'Angebote',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // gruwortandreasgilgabd (3:329)
              margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 0*fem, 27*fem),
              child: Text(
                'Grußwort Andreas Gilg',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // sehrgeehrtedamenundherrenesfre (3:330)
              margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 0*fem, 257*fem),
              constraints: BoxConstraints (
                maxWidth: 1083*fem,
              ),
              child: RichText(
                text: TextSpan(
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.2125*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                  children: [
                    TextSpan(
                      text: 'Sehr geehrte Damen und Herren, es freut mich, dass Sie sich für die Homepage unserer Schule interessieren. Das Wichtigste an einer Schule sind die Kinder, so auch natürlich bei uns. Alle Arbeit ist auf die optimale Erziehung und schulische Förderung der uns anvertrauten Schülerinnen und Schüler ausgerichtet. Die Schulfamilie soll als Ganzes gelebt und geachtet werden. Aber gerade neben dem allgemeinen Bildungs- und Erziehungsauftrag jeder Schule sind unsere besonderen Schwerpunkte:\nUnterstützung der Schülerinnen und Schüler bei der beruflichen Orientierung\nBesondere Förderung und der Schülerinnen und Schüler im MINT-Bereich\nVorbildwirkung und Umwelterziehung der Schülerinnen und Schüler als „Umweltschule“\nVorbildwirkung für Toleranz und Respekt als „Schule ohne Rassismus, Schule mit Courage“\nVerkehrserziehung und Sicherheit\nSchwerpunkt Theater/Schultheater und Musik\n\n\nUnsere Jahrgangsstufen stehen dabei unter einem besonderen pädagogischen Gesamtkonzept:\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 5',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: ' -> „ankommen an der Realschule, Neues kennen lernen“\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 6',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: ' -> „sich orientieren, in der Gruppe und für die richtige Zweigwahl"\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 7 ',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: '-> „sich ausprobieren, in der neuen Klassengemeinschaft“\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 8',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: ' -> „wachsen und sich finden, in der Klasse und der Gemeinschaft“\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 9',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: ' -> „sich entscheiden, Berufswahl und Charakterbildung“\n',
                    ),
                    TextSpan(
                      text: 'Jahrgangsstufe 10',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                    TextSpan(
                      text: ' -> „gestalten, Abschluss und neue Lebenswege“',
                    ),
                  ],
                ),
              ),
            ),
            Container(
              // aktuellesfw9 (3:334)
              margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 0*fem, 1.5*fem),
              child: Text(
                'Aktuelles',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // alleneuigkeitenanunsererschule (3:335)
              margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 0*fem, 0*fem),
              constraints: BoxConstraints (
                maxWidth: 343*fem,
              ),
              child: Text(
                'Alle Neuigkeiten an unserer Schule erfahrt ihr in unserem Blog.',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogrouphvwjHhd (71pC3zBiE8tNmXjdxuHVWj)
              padding: EdgeInsets.fromLTRB(32*fem, 19*fem, 31*fem, 223*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupoud5QnF (71pAjGtXsWGfKJ8eimoud5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                    width: double.infinity,
                    height: 229*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame1iY3 (9:5)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundmmD (13:9)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-hrK.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (9:3)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023AYT (9:4)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame2fEK (13:51)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundvg3 (13:54)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-WPd.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:53)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023YBd (13:52)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame3Eq9 (13:55)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundXJT (13:58)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-Ddu.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:57)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september20238p3 (13:56)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame4EMH (13:59)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // background6eP (13:62)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-a7u.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:61)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023heB (13:60)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame5bjZ (13:63)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundH6b (13:66)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-FpX.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:65)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september20235o9 (13:64)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouprh1mnSf (71pBRqZH4yt7GMV3JkrH1M)
                    width: double.infinity,
                    height: 229*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame6v35 (13:67)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundPhM (13:70)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-aBV.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:69)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023b2j (13:68)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame76EP (13:71)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundZtf (13:74)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-mmV.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:73)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023Xyu (13:72)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame83BZ (13:75)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundKPy (13:78)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:77)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023hvK (13:76)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame9QZq (13:79)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundHNj (13:82)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-iCj.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:81)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september20236LB (13:80)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 40*fem,
                        ),
                        Container(
                          // frame10bnj (13:83)
                          padding: EdgeInsets.fromLTRB(15*fem, 21*fem, 15*fem, 17*fem),
                          width: 194*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x26050505),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur (
                                sigmaX: 0.5*fem,
                                sigmaY: 0.5*fem,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // backgroundGts (13:86)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                                    width: 120*fem,
                                    height: 116*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/background-fL7.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // neuelehrkrfteundneuesseminar20 (13:85)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 4*fem),
                                    constraints: BoxConstraints (
                                      maxWidth: 148*fem,
                                    ),
                                    child: Text(
                                      'Neue Lehrkräfte und neues Seminar 2025',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // september2023gxb (13:84)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                    child: Text(
                                      '18. September 2023',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottombZm (13:87)
              padding: EdgeInsets.fromLTRB(23*fem, 8*fem, 121*fem, 5*fem),
              width: double.infinity,
              height: 131*fem,
              decoration: BoxDecoration (
                color: Color(0x66383838),
              ),
              child: ClipRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur (
                    sigmaX: 4*fem,
                    sigmaY: 4*fem,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupbpmm5Uw (71pFTPWnmgxEwz3stTBPmm)
                        margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 238*fem, 12*fem),
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image1biB (13:123)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                              width: 204*fem,
                              height: 54*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(5*fem),
                                child: Image.asset(
                                  'assets/page-1/images/image-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Center(
                              // staatlicherealschulehauzenberg (13:124)
                              child: Text(
                                'Staatliche Realschule Hauzenberg',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  decoration: TextDecoration.underline,
                                  color: Color(0x7fffffff),
                                  decorationColor: Color(0x7fffffff),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupwvpo34P (71pFcPFoRFPy2a97bDWVpo)
                        margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 27*fem, 11*fem),
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              // information9dD (13:128)
                              'Information',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            Container(
                              // diestaatlicherealschulehauzenb (13:129)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                              constraints: BoxConstraints (
                                maxWidth: 184*fem,
                              ),
                              child: Text(
                                'Die Staatliche Realschule Hauzenberg-Johann-Riederer-Schule- gehört zum Landkreis Passau als Sachaufwandsträger.',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            Container(
                              // platzhalter8k3 (13:125)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                              child: Text(
                                '© 2024 Platzhalter',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 8*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            Text(
                              // allrightsreservedrAF (13:126)
                              'All Rights Reserved.\n',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 7*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupfbxxz1Z (71pFnYdY3ETFQwTvDbfBxX)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 57*fem),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // rechtlicheangabenWVh (13:130)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                              child: Text(
                                'Rechtliche Angaben\n',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            Container(
                              // impresumpWP (13:131)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                              child: Text(
                                'Impresum',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            Text(
                              // datenschutzerklrungLUj (13:132)
                              'Datenschutzerklärung',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupzrysFrb (71pG1Cw7Ayy1bh9WYJZrYs)
                        width: 185*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // autogroupfxyxnbd (71pGY2P6Ambb8SuE7dFXYX)
                              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    // kontakt7du (13:133)
                                    'Kontakt\n',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5*fem,
                                  ),
                                  Container(
                                    // autogroupvywv31m (71pGAx9sNfwt1zkBYxvYwV)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // phoneiconN43 (13:134)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(3*fem, 3*fem, 3*fem, 3*fem),
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x4c1a1a1a),
                                            borderRadius: BorderRadius.circular(5*fem),
                                          ),
                                          child: Center(
                                            // phoneauricularsymbol1smV (13:135)
                                            child: SizedBox(
                                              width: 14*fem,
                                              height: 14*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/phone-auricular-symbol-1-jo1.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // datenschutzerklrungbxP (13:140)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'Datenschutzerklärung',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2125*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5*fem,
                                  ),
                                  Container(
                                    // autogroupasymJ67 (71pGHhTdMqnB5SK7L3Asym)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // phoneiconDis (13:136)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(3*fem, 3*fem, 3*fem, 3*fem),
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x4c1a1a1a),
                                            borderRadius: BorderRadius.circular(5*fem),
                                          ),
                                          child: Center(
                                            // phoneauricularsymbol1XjZ (13:137)
                                            child: SizedBox(
                                              width: 14*fem,
                                              height: 14*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/phone-auricular-symbol-1-Htf.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // datenschutzerklrungTt7 (13:141)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'Datenschutzerklärung',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2125*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupbcrzaSw (71pGQ7ScDB9jmE6jQwBcRZ)
                              width: double.infinity,
                              height: 37*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // phoneiconKfR (13:138)
                                    margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 4*fem, 9*fem),
                                    padding: EdgeInsets.fromLTRB(3*fem, 3*fem, 3*fem, 3*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x4c1a1a1a),
                                      borderRadius: BorderRadius.circular(5*fem),
                                    ),
                                    child: Center(
                                      // phoneauricularsymbol1RyM (13:139)
                                      child: SizedBox(
                                        width: 14*fem,
                                        height: 14*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/phone-auricular-symbol-1-yDM.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // staatlicherealschulehauzenberg (13:142)
                                    constraints: BoxConstraints (
                                      maxWidth: 161*fem,
                                    ),
                                    child: Text(
                                      'Staatliche Realschule\nHauzenberg Eckmühlstraße 24 94051 Hauzenberg',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 10*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}